/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package emergencyroomadmissionssystem;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Main class to handle hospital admission system.
 * This includes patient information and eligibility checks.
 *
 * @author Darsh Somayi
 */

// Base class representing a generic patient
class Patient {
    String name;
    int age;
    String gender;

    // Constructor to initialize patient details
    Patient(String name, int age, String gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }
    
    // Method to display patient's basic information
    public void displayEligibility() {
        System.out.println("Patient Name: " + name + ", Age: " + age + ", Gender: " + gender);
    }
}

// Subclass representing female patients
class FemalePatient extends Patient {

    // Constructor specific to female patients
    FemalePatient(String name, int age) {
        super(name, age, "Female");
    }

    // Overridden method to display eligibility for treatment based on age
    @Override
    public void displayEligibility() {
        super.displayEligibility();
        if (age < 18) {
            System.out.println("Status: Ineligible for treatment.");
        } else {
            System.out.println("Status: Eligible for treatment at Durban (DBN) Hospital.");
        }
    }
}

// Subclass representing male patients
class MalePatient extends Patient {
    boolean hasChronicDisorder;

    // Constructor specific to male patients, including chronic disorder status
    MalePatient(String name, int age, boolean hasChronicDisorder) {
        super(name, age, "Male");
        this.hasChronicDisorder = hasChronicDisorder;
    }

    // Overridden method to display eligibility for treatment based on age and chronic disorder status
    @Override
    public void displayEligibility() {
        super.displayEligibility();
        if (age > 18) {
            if (hasChronicDisorder) {
                System.out.println("Status: Transferred to Johannesburg (JHB) Hospital for specialized care.");
            } else {
                System.out.println("Status: Eligible for treatment at Durban (DBN) Hospital.");
            }
        } else {
            System.out.println("Status: Ineligible for emergency treatment.");
        }
    }
}

// Main class to handle login and display patient eligibility
public class HospitalAdmissionSystem {

    // Method to handle the login process
    private static boolean login() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        // Validates the login credentials
        return username.equals("Admin") && password.equals("D1234");
    }

    // Main method where the program starts execution
    public static void main(String[] args) {
        // If login fails, exit the application
        if (!login()) {
            System.out.println("Invalid credentials! Exiting the application.");
            return;
        }

        // Creating a list of patients with different attributes
        List<Patient> patients = new ArrayList<>();
        patients.add(new MalePatient("John Doe", 20, false));
        patients.add(new FemalePatient("Jane Smith", 17));
        patients.add(new MalePatient("Robert Brown", 30, true));
        patients.add(new FemalePatient("Emily White", 16));
        patients.add(new MalePatient("Michael Johnson", 50, true));
        patients.add(new FemalePatient("Mary Jones", 22));
        patients.add(new MalePatient("David Lee", 18, false));
        patients.add(new FemalePatient("Sophia Davis", 19));

        // Display eligibility status for each patient
        for (Patient patient : patients) {
            patient.displayEligibility();
            System.out.println();
        }
    }
}
